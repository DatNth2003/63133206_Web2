package com.ntd63133206.bookbuddy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookBuddyOnlApplicationTests {

	@Test
	void contextLoads() {
	}

}
